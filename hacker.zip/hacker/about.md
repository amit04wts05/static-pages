---
layout: default
title : About
permalink : /about/
---
<b>About us</b>
<hr>
<img src="{{ site.path }}images/bkg.png">